<?php

$servidor = "localhost";
$usuario = "root";
$clave = "";
$puerto = "3307";
$nombre = "programacion3";

?>