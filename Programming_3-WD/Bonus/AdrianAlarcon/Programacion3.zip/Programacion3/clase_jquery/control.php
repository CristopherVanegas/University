<?php  
	echo "Se guardo la informacion con exito";
?>